<?php

$con = mysqli_connect("localhost","root","","website");

     $username = @$_POST["uname"];
     $password = @$_POST["pass"];

    
$sql = "select * from florist_signup where florist_email='".$username."' and florist_pass='".$password."'";

    $result = mysqli_query($con,$sql);
    
    $res = @mysqli_num_rows($result);
    if($res>0)
    {
      echo "<script>window.open('florist_dashboard.php','_self')</script>";
    }
    
    else
    {
        include("florist-login.php");
        echo "<script>alert('Invalid Login Details')</script>";
    }
?>