<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="gencyolcu" />

	<title>Order Tracking</title>
    <style type="text/css">
    #button{
        display: block; background: #b20000; height: 30px;
        border: 0px solid #e1e1e1;border-radius: 4px;
        color: white;margin-right: 60px;
    }
    
    </style>
</head>

<body>

<?php
include("topbar.php");
include("navbar.php");
?>
<div id="order_tracking">
<form action="" method="">
<table align="center"  width="300" style="background: #FEFDE9;">
<tr>
<th style="background: #fff2cd;font-size: 18px; color: #b20000;padding: 7px;">Order Tracking</th>
</tr>
<tr>
<td align="center">
<label style="padding:  2px 0px; font-size: 18px; color: #666666;">Order No</label>
</td>
</tr>
<tr align="center">
<td><input type="text" name="" value="" placeholder="Enter Order No" required="required"/></td>
</tr>
<tr align="center">
<td><input type="submit" name="submit" value="Track" id="button" /></td>
</tr>
</table>
</form>
</div>
<?php
include("footer.php");
?>
</body>
</html>