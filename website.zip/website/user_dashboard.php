<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="gencyolcu" />

	<title> User Dashboard</title>
    <style type="text/css">
    #dashboard{
        background: white;
        margin: auto;
        width: 1100px;
        height: 250px; 
    }
    #dash_tab td a {
        padding-left: 20px;
        font-size: 18pt;
    }
    
    h3{
    color: #666666;
    font-size: 20pt;
 }
 #dash_tab td img{
    padding-left: 10px;
 }
 #dash_tab{
    border-radius: 8px;
    background: #f2f2f2;
    box-shadow: 0px 0px 10px #e1e1e1;
    border: 1px solid #e1e1e1;
 }
    </style>
</head>

<body>
<?php
include("topbar.php");
include("navbar.php");
?>
<div id="dashboard">
<h3 align="center">Welcome</h3>
<table  width="600" align="center" id="dash_tab">
<tr>
<td height="50"><img src="images/new-order.png"/><a href="" >Make Order</a></td>
<td><img src="images/order-tracking.png"/><a href="">Track Order</a></td>
</tr>
<tr>
<td height="50"><img src="images/personal-details.png"/><a href="">Profile Update</a></td>
<td><img src="images/logout.jpg"/><a href="user-login.php">Logout</a></td>
</tr>
</table>
</div>
<?php
include("footer.php");
?>
</body>
</html>