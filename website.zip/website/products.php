<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="gencyolcu" />

	<title>Products</title>
    <style type="text/css">
    #li_style{
    height: 30px;
    background:#ec9b4a;
    line-height: 28px;
    color: #ffffff;
    font-size: 14pt;
    padding-left:20px;
    padding-right:20px;
    margin-top: 10px;
    margin-bottom: 10px;
    }
    #list_style{
        list-style: none;
        height: 28px;
        display: block;
        color: #666666;
        border-bottom:1px dotted #e5e5e5;
        border-top:1px dotted #e5e5e5;
        padding-top: 5px;
    }
    #style{
        background: white;
        padding-left: 5px;
        padding-right: 5px;
        text-align: center;
    }
    #left_side{
        border: 3px solid #e5e5e5;
    }
    </style>
</head>

<body>

<?php

include("topbar.php");
include("navbar.php");

?>
<div id="pro_body">

<div id="left_side">
<table  width="195">
<tr>
<td>
<ul id="style">
<li id="li_style">Most Popular</li>
<li id="list_style">Birthday</li>
<li id="list_style">Anniversary</li>
<li id="li_style">Categories</li>
<?php
                
                $con = mysqli_connect("localhost","root","","website");
                
                $sql = "select * from product_cat where status=1";
                
                $result = mysqli_query($con,$sql);
                
                while($row = mysqli_fetch_array($result)){
                    
                    $product_id = $row[0];
                    $product_title = $row[1];
                  
                  
                  echo "<li id='list_style'><a href='products.php?pro=$product_id' style='color:#666666;'>$product_title</a></li>";   
            }
?>

<li id="li_style">Occasion</li>
<?php
$con = mysqli_connect("localhost","root","","website");
                
                $sql1 = "select * from occasion_cat where status=1";
                
                $result1 = mysqli_query($con,$sql1);
                
                while($row1 = mysqli_fetch_array($result1)){
                    
                    $occasion_id = $row1[0];
                    $occasion_title = $row1[1];
                  
                  
                  echo "<li id='list_style'>$occasion_title</li>";   
            }
?>
<li id="li_style">Varieties</li>
<?php
$con = mysqli_connect("localhost","root","","website");
                
                $sql = "select * from varieties where status=1";
                
                $result = mysqli_query($con,$sql);
                
                while($row = mysqli_fetch_array($result)){
                    
                    $var_id = $row[0];
                    $var_title = $row[1];
                  
                  
                  echo "<li id='list_style'>$var_title</li>";   
            }

?>
<li id="li_style">Color</li>
<?php
$con = mysqli_connect("localhost","root","","website");
                
                $sql = "select * from color where status=1";
                
                $result = mysqli_query($con,$sql);
                
                while($row = mysqli_fetch_array($result)){
                    
                    $col_id = $row[0];
                    $col_title = $row[1];
                  
                  
                  echo "<li id='list_style'>$col_title</li>";   
            }
?>
</ul>
</td>
</tr>
</table>
</div>
<div id="right_side">
<h1>Flowers Delivery in Mumbai</h1>
</div>
<?php

$con = mysqli_connect("localhost","root","","website");

if(!$con){
    die("Error in Connection");
}

    $pro_id = @$_GET['pro'];
    
    if(isset($_GET['pro'])){

$sql = "select * from product where pro_cat_id = '".$pro_id."'";

$result = mysqli_query($con,$sql);
                
                while($row = mysqli_fetch_array($result)){
              
              $product_id = $row[0];      
              $product_image = $row[6];  
              $product_title = $row[1];
              $product_price = $row[7]; 
                
?>
<div id="product_body">
<table>
<tr>
<td><a href=""><img src="admin/product_image/<?php echo $product_image;?>" alt="" width="200" height="220" id="text3"/></a></td>
</tr>
<tr>
<td align="center"><a id="text2" href="page.php?pro=<?php echo $product_id;?>"><?php echo $product_title;?></td></a>
</tr>
<tr>
<td align="center"><span id="text4"><?php echo $product_price;?></span></td>
</tr>
</table>
</div>
</div>
<?php }}?>
<?php
include("footer.php");
?>
</body>
</html>


