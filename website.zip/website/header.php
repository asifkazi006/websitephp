<div id="header"> <!-- header section start-->
   <div id="sliderFrame">
        <div id="slider">
            <a href="index.php">
                <img src="images/banner1.jpg" alt=""/>
            </a>
            <a href="index.php">
                <img src="images/banner2.jpg" alt=""/>
            </a>
            <a href="index.php">
                <img src="images/banner3.jpg" alt=""/>
            </a>
            
        </div>
        
    </div>
    <hr/>
    <marquee style="padding-top: 1px; font-size:13pt;">Same Day Delivery of Flowers and Gifts. Order before 4.00 pm</marquee>
</div> <!-- header section ends-->
