<div id="navbar">
    <ul>
        <li><a href="index.php">Home</a></li>
        <li>
            <a href="">Products</a>
            <ul class="dropdown">
                <?php
                
                $con = mysqli_connect("localhost","root","","website");
                
                $sql = "select * from product_cat where status=1";
                
                $result = mysqli_query($con,$sql);
                
                while($row = mysqli_fetch_array($result)){
                    
                    $product_id = $row[0];
                    $product_title = $row[1];
                  
                  
                  echo "<li><a href='products.php?pro=$product_id'>$product_title</a></li>";   
            }
            ?>
            </ul>
        </li>
		<li>
            <a href="#">Occasions</a>
            <ul class="dropdown">
                <?php
                
                $con = mysqli_connect("localhost","root","","website");
                
                $sql1 = "select * from occasion_cat where status=1";
                
                $result1 = mysqli_query($con,$sql1);
                
                while($row1 = mysqli_fetch_array($result1)){
                    
                    $occasion_id = $row1[0];
                    $occasion_title = $row1[1];
                  
                  
                  echo "<li><a href='occasions.php?occ=$occasion_id'>$occasion_title</a></li>";   
            }
            ?>
            </ul>
        </li>
		<li>
            <a href="#">Varieties</a>
            <ul class="dropdown">
                <?php
                
                $con = mysqli_connect("localhost","root","","website");
                
                $sql = "select * from varieties where status=1";
                
                $result = mysqli_query($con,$sql);
                
                while($row = mysqli_fetch_array($result)){
                    
                    $var_id = $row[0];
                    $var_title = $row[1];
                  
                  
                  echo "<li><a href=''>$var_title</a></li>";   
            }
            ?>
            </ul>
        </li>
		<li>
            <a href="#">Color</a>
            <ul class="dropdown">
              <?php
                
                $con = mysqli_connect("localhost","root","","website");
                
                $sql = "select * from color where status=1";
                
                $result = mysqli_query($con,$sql);
                
                while($row = mysqli_fetch_array($result)){
                    
                    $col_id = $row[0];
                    $col_title = $row[1];
                  
                  
                  echo "<li><a href=''>$col_title</a></li>";   
            }
            ?>
            </ul>
        </li>
        <li><a href="index.php">Price</a></li>
        <li><a href="hot_offer.php">Hot Offers</a></li>
        <li><a href="contact.php">Contact Us</a></li>
    </ul>
</div>
 
               