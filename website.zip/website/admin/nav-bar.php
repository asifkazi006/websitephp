<div id="primary_nav_wrap">
<ul>
  <li class="current-menu-item"><a href="welcome.php">Home</a></li>
  <li><a href="manage_order.php">My Order</a></li>
  <li><a href="">Category</a>
    <ul>
      <li><a href="add_category.php">Add Category</a></li>
      <li><a href="edit_category.php">Edit Category</a></li>
    </ul>
  </li>
  <li><a href="">Occasion</a>
    <ul>
      <li class="dir"><a href="add_occasion.php">Add Occasion</a></li>
      <li class="dir"><a href="edit_occasion.php">Edit Occasion</a>
      </li>
    </ul>
  </li>
  <li><a href="">Varieties</a>
    <ul>
      <li class="dir"><a href="add_var.php">Add Varieties</a></li>
      <li class="dir"><a href="edit_var.php">Edit Varieties</a>
      </li>
    </ul>
  </li>
  <li><a href="">Color</a>
    <ul>
      <li class="dir"><a href="add_color.php">Add Color</a></li>
      <li class="dir"><a href="edit_color.php">Edit Color</a>
      </li>
    </ul>
  </li>
  <li><a href="search.php">Search Order</a></li>
<li><a href="">Customer</a>
    <ul>
      <li class="dir"><a href="all_customer.php">Search Customer</a></li>
      <li class="dir"><a href="customer_detail.php">All Customer</a>
      </li>
    </ul>
  </li>
  <li><a href="">Vendor</a>
    <ul>
      <li class="dir"><a href="all_vendor.php">Search Vendor</a></li>
      <li class="dir"><a href="vendor_detail.php">All Vendor</a>
      </li>
    </ul>
  </li>
  <li><a href="additem.php">Add Item</a></li>
 </ul>
</div>