<?php

session_start();

if(!isset($_SESSION['uname'])){
		
		header("location:index.php");
		
}
else{
	
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="gencyolcu" />

	<title>Change Password</title>
    <link rel="stylesheet" href="css/style.css"/>
    <style type="text/css">
    table h2{
        color: #c10000;
        float: left;
        margin-left: 100px;
    }
     #tab1
    {
        margin-top: 20px;
        height: 28px;
    }
    </style>
</head>

<body>
<?php
include("header.php");
include("nav-bar.php");
?>
<table width="1350">
<tr>
<th><h2>My Profile</h2></th>
</tr>
</table>
<hr />
</table>
<table width="400" align="center" id="tab1">
<tr>
<td><b>User Type</b></td>
<td>Administrator</td>
</tr>
<tr>
<td><b>Email</b></td>
<td>abc@gmail.com</td>
</tr>
<tr>
<td><b>Company Name<b></td>
<td>Company Name</td>
</tr>
<tr>
<td><b>Full Name</b></td>
<td>Full Name</td>
</tr>
<tr>
<td><b>Mobile No</b></td>
<td>Mobile No</td>
</tr>
<tr>
<td><b>Alternate Email</b></td>
<td>Alternate Email</td>
</tr>
</table>
<?php
include("footer.php");
?>
</body>
</html>
<?php } ?>