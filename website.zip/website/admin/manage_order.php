<?php

session_start();

if(!isset($_SESSION['uname'])){
		
		header("location:index.php");
		
}
else{
	
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="gencyolcu" />

	<title>Manage Order</title>
    <link rel="stylesheet" href="css/style.css"/>
    <style type="text/css">
    #orders{
        width: 1350px;
        background: white;
        height: auto;
        margin-top: 20px;
    }
     #orders td{
        float:next;
        padding-right: 100px;
        color: #c10000;
    }
    #orders th{
        color: #c10000;
    }
    #tab td{
        text-align: center;
        border:1px solid #f1f1f1;
        border-left: 0px;
        border-top: 0px;
        background-color: #f7f7f7;
        font-size: 16px;
        padding: 6px;
        color: #666666;
        font-weight: bold;
    }
    </style>
</head>

<body>
<?php
include("header.php");
include("nav-bar.php");
?>
<div id="orders">
<form action="" method="post" enctype="multipart/form-data">
<table width="1350">
<tr>
<th><h2>Search Orders</h2></th>
<td><h3>Search (Order ID)</h3><input type="text" name="search" value="" placeholder="Enter Order ID" required="required" size="20"/>
<input type="submit" name="submit" value="Search"/>
</td>
</tr>
</table>
</form>
</div><br />
<hr />
<h2 align="center" style="color:#c10000;">All Orders</h2>
<table width="1000" border="1" align="center" id="tab"   >
<tr>
<td>Order ID</td>
<td>Delivery Date</td>
<td>Receiver Name</td>
<td>Amount</td>
<td>Payment Method</td>
<td>Action</td>
</tr>
</table>
<?php
include("footer.php");
?>
</body>
</html>
<?php } ?>