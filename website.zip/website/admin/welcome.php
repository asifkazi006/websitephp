<?php

session_start();

if(!isset($_SESSION['uname'])){
		
		header("location:index.php");
		
}
else{
	
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="gencyolcu" />

	<title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/style.css"/>
</head>

<body>
<?php
include("header.php");
include("nav-bar.php");
?>
<div id="admin-body">
<div id="heading" align="center">
<h1>Welcome to Admin Control Panel</h1>
<img src="images/logo.jpg" alt="logo-heading"/>
</div>
</div>
<?php
include("footer.php");
?>
</body>
</html>
<?php } ?> 