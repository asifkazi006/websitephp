<div id="admin-footer">
<p>Copyright 2016 &copy www.xyz.com all rights reserved</p>
</div>
