<div id="top-bar">
<a href="welcome.php"><img src="images/logo.jpg" alt="logo" height="50" style="float: left;"/></a>
<ul id="top-menu">
<li style="font-size: 15pt;font-family: cursive;">Welcome <?php echo @$_SESSION['uname'];?></li>
<li><a href="welcome.php">Home</a></li>
<li><a href="profile.php">Profile</a></li>
<li><a href="change_password.php">Change Password</a></li>
<li><a href="logout.php">Logout</a></li>
</ul>
</div>