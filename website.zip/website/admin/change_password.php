<?php

session_start();

if(!isset($_SESSION['uname'])){
		
		header("location:index.php");
		
}
else{
	
?>
<?php
$con = mysqli_connect("localhost","root","","website");

    if(isset($_POST['submit']))
    {
        $old_pass = $_POST['old_pass'];
        
        $sql = "select * from admin_login where admin_pass='".$old_pass."'";
        
        $result = mysqli_query($con,$sql);
        $old_password="NA";
        
        while($row=mysqli_fetch_assoc($result))
        {
             $old_password = $row["admin_pass"];
                         
        }
        if($old_password==="NA")
        {
            
       echo "<script>alert('Invalid Old Password')</script>";     
        }
        else
        {
            $new_pass = $_POST['new_pass'];
            $con_new_pass = $_POST['con_new_pass'];
            
            if($new_pass===$con_new_pass)
            {
                $sql = "update admin_login set admin_pass='".$new_pass."' where admin_pass='".$old_password."'";
                
                $result = mysqli_query($con,$sql);
                
                echo "<script>alert('Password Updated Successfully')</script>";
                echo "<script>window.open('index.php','_self')</script>";
                
            }
            else
            {
                  echo "<script>alert('Password does not match')</script>";
            }
      }     
    }
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="gencyolcu" />

	<title>Change Password</title>
    <link rel="stylesheet" href="css/style.css"/>
    <style type="text/css">
    table h2{
        color: #c10000;
        float: left;
        margin-left: 100px;
    }
    #ipt{
        width: 300px;
        background: #ffffff;
        border: 1px solid #D5D5D5;
        height: 28px;
        font-size: 13px;
        padding: 3px;
        color: #000000;
    }
    table th{
        color: #000000;
        font-size: 12px;
        font-family: Verdana,Arial;
    }
    #update{
        background: #c10000;
        border: 0px solid #2f73e5;
        color: #fff;
        font-size: 13px;
        padding: 4px 20px;
        cursor: pointer;
        border-radius: 4px;
        box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.1);
    }
    </style>
</head>

<body>
<?php
include("header.php");
include("nav-bar.php");
?>
<form action="" method="post">
<table width="1350">
<tr>
<th><h2>Change Password</h2></th>
</tr>
</table>
<hr />
<br />
<table width="500" align="center" >
<tr>
<th>Old Password</th>
<td><input type="password" name="old_pass" value="" placeholder="Enter Old Password" required="required" size="20" id="ipt"/></td>
</tr>
<tr>
<th>New Password</th>
<td><input type="password" name="new_pass" value="" placeholder="Enter New Password" size="20" required="required" id="ipt"/></td>
</tr>
<tr>
<th>Confirm New Password</th>
<td><input type="password" name="con_new_pass" value="" placeholder="Confirm New Password" size="20" required="required"id="ipt"/></td>
</tr>
<td colspan="2" align="center"><input type="submit" name="submit" value="Update Password" id="update"/></td>
<tr> 
</tr>
</table>
</form>
<?php
include("footer.php");
?>
</body>
</html>
<?php } ?>