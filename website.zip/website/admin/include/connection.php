<?php

$con = mysqli_connect("localhost","root","","website");

    if(!$con)
    {
        die("Error in Connection");
    }
?>