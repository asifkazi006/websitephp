<?php

session_start();

if(!isset($_SESSION['uname'])){
		
		header("location:index.php");
		
}
else{
	
?>
<?php
$con = mysqli_connect("localhost","root","","website");
    
    $vendor_id = @$_GET["id"];
    
$sql = "select * from florist_signup where florist_id='".$vendor_id."'";
    
    $result = mysqli_query($con,$sql);
    
    
    while($row = mysqli_fetch_array($result))
    {   
        $vendor_id = $row[0];
        $uname = $row[1];
        $fname = $row[4];
        $cname = $row[5];
        $address = $row[6];
        $city = $row[7];
        $state = $row[8];
        $zipcode = $row[9];
        $country = $row[10];
        $mobile = $row[11];
        $alt_email = $row[12];
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>Edit Vendor</title>
    <link rel="stylesheet" href="css/style.css"/>
    <style type="text/css">
    #cust{
    margin-top: 50px;
    }
    table td{
        text-align: center;
    }
    </style>
</head>

<body>
<?php
include("header.php");
include("nav-bar.php");
?>
<div id="cust">
<h2 align="center">Edit Vendor</h2>
<table width="400"  align="center">
<form action="edit_vendor.php?edit_form=<?php echo $vendor_id;?>" method="post">
<tr>
<td><b>Username or Email</b></td>
<td><input type="text" name="uname" value="<?php echo $uname;?>" required="required"/><span> * </span></td>
</tr>
<tr>
<td><b>Full Name</b></td>
<td><input type="text" name="fname" value="<?php echo $fname;?>" required="required"/><span> * </span></td>
</tr>
<tr>
<td><b>Company Name</b></td>
<td><input type="text" name="cname" value="<?php echo $cname;?>" required="required"/><span> * </span></td>
</tr>
<tr>
<td><b>Address<b></td>
<td><textarea rows="4" cols="22" name="address" required="required"><?php echo $address;?></textarea><span> * </span></td>
</tr>
<tr>
<td><b>City</b></td>
<td><input type="text" name="city" value="<?php echo $city;?>" required="required"/><span> * </span></td>
</tr>
<tr>
<td><b>State</b></td>
<td><input type="text" name="state" value="<?php echo $state;?>" required="required"/><span> * </span></td>
</tr>
<tr>
<td><b>ZipCode</b></td>
<td><input type="text" name="zip" value="<?php echo $zipcode;?>" required="required"/><span> * </span></td>
</tr>
<tr>
<td><b>Country</b></td>
<td><input type="text" name="country" value="<?php echo $country;?>" required="required"/><span> * </span></td>
</tr>
<tr>
<td><b>Mobile</b></td>
<td><input type="text" name="mobile" value="<?php echo $mobile;?>" required="required"/><span> * </span></td>
</tr>
<tr>
<td><b>Alt Email</b></td>
<td><input type="text" name="alt_email" value="<?php echo $alt_email;?>" required="required"/><span> * </span></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="submit" value="Update"/></td>
</tr>
<?php } ?>
</form>
</table>
<?php
$con = mysqli_connect("localhost","root","","website");

    if(isset($_POST["submit"]))
    {
        $ven_id = $_GET['edit_form'];
        $u_name = $_POST['uname'];
        $u_fname = $_POST['fname'];
        $u_cname = $_POST['cname'];
        $u_address = $_POST['address'];
        $u_city = $_POST['city'];
        $u_state = $_POST['state'];
        $u_zipcode = $_POST['zip'];
        $u_country = $_POST['country'];
        $u_mobile = $_POST['mobile'];
        $u_alt_email = $_POST['alt_email'];
        
        $sql = "update florist_signup set florist_email='".$u_name."',florist_fullname='".$u_fname."',florist_comp='".$u_cname."',florist_add='".$u_address."',
        florist_city='".$u_city."',florist_state='".$u_state."',florist_zip='".$u_zipcode."',florist_country='".$u_country."',florist_mobile='".$u_mobile."',florist_alt_email='".$u_alt_email."' 
        where florist_id='".$ven_id."'";
        
        $result = mysqli_query($con,$sql);
        
        if($result)
        {   
            echo "<script>alert('Vendor Updated Successfully')</script>";
            echo "<script>window.open('vendor_detail.php','_self')</script>";
        }
        else
        {
            echo "Problem in Updating Record";
        }
        
    }
?>
</div>
<?php
include("footer.php");
?>
</body>
</html>
<?php } ?>