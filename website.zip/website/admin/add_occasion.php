<?php

session_start();

if(!isset($_SESSION['uname'])){
		
		header("location:index.php");
		
}
else{
	
?>
<?php
include("header.php");
include("nav-bar.php");
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>Insert Occasion</title>
    <link rel="stylesheet" href="css/style.css"/>
    <style type="text/css">
    #occ{
        float: left;
        margin-left: 100px;
        margin-top: 40px;
    }
     #occ1{
        margin-left: 100px;
        margin-top: 40px;
    }
    
    </style>
</head>

<body>
<div id="occ">
<form action="" method="post">
<h1 align="center" style="color: #FF8000;">Insert Occasion</h1>
<table width="300" height="150" border="2" align="center">
<tr>
<td align="center" style="color: #FF8000;">Occasion Name</td>
<td><input type="text" name="occ_name" value=""/></td>
</tr>
<tr>
<td align="center" colspan="2"><input type="submit" name="submit" value="Insert" style="color: white; background: #FF8080;"/></td>
</tr>
</table>
</form>
</div>
<?php 

$con = mysqli_connect("localhost","root","","website");

if(isset($_POST['submit'])){

$occasion_name = $_POST["occ_name"];

$sql = "insert into occasion_cat (occa_title) values ('$occasion_name')";

$result = mysqli_query($con,$sql);

if($result){
    
    echo "<script>alert('Occasion inserted successfully')</script>";    
}

}
?>
<div id="occ1">
<table width="500" border="2" align="center">
<tr>
<th colspan="3"><h2>Edit Occasion</h2></th>
</tr>
<tr>
<td><h2 align="center">Occasion ID</h2></td>
<td><h2 align="center">Occasion Title</h2></td>
</tr>
<?php

$con = mysqli_connect("localhost","root","","website");

$sql = "select * from occasion_cat";

$result = mysqli_query($con,$sql);

while($run = mysqli_fetch_assoc($result)){
    
    $occasion_id = $run['occa_id'];
    $occasion_title = $run['occa_title'];
    $status=$run['status'];
?>
<tr>
<td align="center"><?php echo $occasion_id;?></td>
<td align="center"><?php echo $occasion_title;?></td>
</tr>
<?php } ?>
</table>
</div>
<?php
include("footer.php");
?>
</body>
</html>
<?php } ?>