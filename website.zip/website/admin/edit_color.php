<?php

session_start();

if(!isset($_SESSION['uname'])){
		
		header("location:index.php");
		
}
else{
	
?>
<?php
include("header.php");
include("nav-bar.php");
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>Edit Color</title>
    <link rel="stylesheet" href="css/style.css"/>
    <style type="text/css">
    #link1{
        text-decoration: none;
        color: #0F0;
    }
    #link2{
        text-decoration: none;
        color:#F00;
    }
    #cont{
        margin-top: 50px;
    }
    </style>
</head>

<body>
<div id="cont">
<table width="500" border="2" align="center">
<tr>
<th colspan="3"><h2>Edit Color</h2></th>
</tr>
<tr>
<td><h2 align="center">Color ID</h2></td>
<td><h2 align="center">Color Title</h2></td>
<td><h2 align="center">Status</h2></td>
</tr>
<?php

$con = mysqli_connect("localhost","root","","website");

$sql = "select * from color";

$result = mysqli_query($con,$sql);

while($run = mysqli_fetch_assoc($result)){
    
    $col_id = $run['col_id'];
    $col_title = $run['col_name'];
    $status=$run['status'];
?>
<tr>
<td align="center"><?php echo $col_id;?></td>
<td align="center"><?php echo $col_title;?></td>
<?php
if(($status)=='0')
{
?>
 <td align="center"><a  id="link1" href="edit_color.php?status=<?php echo $run['col_id'];?>" 
onclick="return confirm('Activate <?php echo $col_title?>');">Deactivate</a></td>
<?php
}
if(($status)=='1')
{
?>
<td align="center"><a id="link2" href="edit_color.php?status=<?php echo $run['col_id'];?>" 
onclick="return confirm('De-activate <?php echo $col_title?>');">Activate</a></td>
<?php
}
?>
</tr>
<?php } ?>
<?php
$con = mysqli_connect("localhost","root","","website");
if(isset($_GET['status'])){
    
    $status1= $_GET['status'];
    $select="select * from color where col_id='$status1'";
    $select1=mysqli_query($con,$select);
    while($row=mysqli_fetch_object($select1))
{
$status_var=$row->status;
if($status_var=='0')
{
$status_state=1;
}
else
{
$status_state=0;
}
$update="update color set status='$status_state' where col_id='$status1' ";
$update1 = mysqli_query($con,$update);
if($update1)
{
echo "<script>window.open('edit_color.php','_self')</script>";
}
else
{
echo mysql_error();
}
}
?>
<?php
}
?>
</table>
</div>
<?php
include("footer.php");
?>
</body>
</html>
<?php } ?>