<?php
session_start();
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="gencyolcu" />

	<title>Admin Login</title>
    <link rel="stylesheet" href="css/style.css"/>
</head>

<body>
<div align="center" style="margin-top: 100px;">
<img src="images/logo.jpg" alt=""/>
<h2 style="color: lime;">CPanel Login</h2>
<form action="" method="post">
<table width="200" align="center" border="5">
<tr>
<td>Username</td>
<td><input type="text" name="uname" value="" required="required"/></td>
</tr>
<tr>
<td>Password</td>
<td><input type="password" name="pass" value="" required="required"/></td>
</tr>
<tr>
<td align="center" colspan="5"><input type="submit" name="submit" value="Login to Cpanel"/></td>
</tr>
</table>
</form>
<?php
include("footer.php");
?>
</div>
</body>
</html>
<?php

$con = mysqli_connect("localhost","root","","website");

if(!$con)
{
    die("Error in connection");
}

    if(isset($_POST["submit"]))
    {
    $uname = $_POST["uname"];
    $pass= $_POST["pass"];
    
    $sql = "select * from admin_login where admin_uname = '" . $uname . "' AND admin_pass = '" . $pass . "'";
    
    $result = mysqli_query($con,$sql);
    
    if(mysqli_num_rows($result) == 1)
    {
      $_SESSION['uname'] = $uname;
      echo "<script>window.open('welcome.php','_self')</script>";
    }
    
    else
    {
        echo "<script>alert('Invalid Login Details')</script>";
    }
    }
?>
