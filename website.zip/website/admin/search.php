<?php

session_start();

if(!isset($_SESSION['uname'])){
		
		header("location:index.php");
		
}
else{
	
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="gencyolcu" />

	<title>Search Product</title>
    <link rel="stylesheet" href="css/style.css"/>
    <style type="text/css">
    #search th{
        color: #c10000;
    }
    #search td{
        float: right;
        padding-right: 100px;
        color: #c10000;
    }
    .table td{
        border:1px solid #f1f1f1;
        border-left: 0px;
        border-top: 0px;
        background-color: #f7f7f7;
        font-size: 14px;
        padding: 6px;
        color: #666666;
        font-weight: bold;
    }
    
    </style>
</head>

<body>
<?php
include("header.php");
include("nav-bar.php");
?>
<div id="search">
<form action="search_item.php" method="get" enctype="multipart/form-data">
<table width="1350">
<tr>
<th><h2>Search Item</h2></th>
<td><h3>Search (Product ID)</h3><input type="text" name="search" value="" placeholder="Product Id" required="required" size="10"/>
<input type="submit" name="submit" value="Search"/>
</td>
</tr>
</table>
</div>
<hr />
</form>
<?php
include("footer.php");
?>
</body>
</html>
<?php } ?>