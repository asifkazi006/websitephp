<?php

session_start();

if(!isset($_SESSION['uname'])){
		
		header("location:index.php");
		
}
else{
	
?>
<?php
include("header.php");
include("nav-bar.php");
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>Customer Details</title>
    <link rel="stylesheet" href="css/style.css"/>
    <style type="text/css">
    #search th{
        color: #c10000;
    }
    #search td{
        float: right;
        padding-right: 100px;
        color: #c10000;
    }
    #tab td{
        text-align: center;
        border:1px solid #f1f1f1;
        border-left: 0px;
        border-top: 0px;
        background-color: #f7f7f7;
        font-size: 16px;
        padding: 6px;
        color: #666666;
        font-weight: bold;
    }
    
    </style>
</head>
<body>
<div id="search">
<form action="" method="get" enctype="multipart/form-data">
<table width="1350">
<tr>
<th><h2>Search Customer</h2></th>
<td><h3>Search (Customer Name)</h3><input type="text" name="search" value="" placeholder="Customer Name" required="required" size="20"/>
<input type="submit" name="submit" value="Search"/>
</td>
</tr>
</table>
</div>
<hr />
</form>
<h2 align="center" style="color: #c10000;">Customer Details</h2>
<table width="900" border="1" align="center" id="tab">
<tr>
<td>Cust ID</td>
<td>Full Name</td>
<td>City</td>
<td>Country</td>
<td>Email ID</td>
<td>Edit</td>
</tr>
<?php
$con = mysqli_connect("localhost","root","","website");

    if(isset($_GET['submit']))
    {
        $cust_name = $_GET['search'];
        
    $sql = "select * from user_signup where user_fullname='".$cust_name."'";
    
    $result = mysqli_query($con,$sql);
    
    while($row = mysqli_fetch_array($result))
    {
        $cust_id = $row[0];
        $full_name = $row[4];
        $city = $row[7];
        $country = $row[10];
        $email = $row[1];

?>
<tr>
<td><?php echo $cust_id;?></td>
<td><?php echo $full_name;?></td>
<td><?php echo $city;?></td>
<td><?php echo $country;?></td>
<td><?php echo $email;?></td>
<td><a href='edit_customer.php?id=<?php echo $cust_id;?>' style="text-decoration: none;">Edit</a></td>
</tr>
<?php }} ?>
</table> 
<?php
include("footer.php");
?>
</body>
</html>
<?php } ?>