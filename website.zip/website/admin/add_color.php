<?php

session_start();

if(!isset($_SESSION['uname'])){
		
		header("location:index.php");
		
}
else{
	
?>
<?php
include("header.php");
include("nav-bar.php");
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>Insert Color</title>
    <link rel="stylesheet" href="css/style.css"/>
    <style type="text/css">
    #col{
        float: left;
        margin-left: 100px;
        margin-top: 40px;
    }
    #col1{
        margin-top: 40px;
        margin-left: 100px;
    }
    </style>
</head>

<body>
<div id="col">
<form action="" method="post">
<h1 align="center" style="color: #FF8000;">Insert Color</h1>
<table width="300" height="150" border="2" align="center">
<tr>
<td align="center" style="color: #FF8000;">Color Name</td>
<td><input type="text" name="col_name" value=""/></td>
</tr>
<tr>
<td align="center" colspan="2"><input type="submit" name="submit" value="Insert" style="color: white; background: #FF8080;"/></td>
</tr>
</table>
</form>
</div>
<?php 

$con = mysqli_connect("localhost","root","","website");

if(isset($_POST['submit'])){

$col_name = $_POST["col_name"];

$sql = "insert into color (col_name) values ('$col_name')";

$result = mysqli_query($con,$sql);

if($result){
    
    echo "<script>alert('color inserted successfully')</script>";
}

}
?>
<div id="col1">
<table width="500" border="2" align="center">
<tr>
<th colspan="3"><h2>Color</h2></th>
</tr>
<tr>
<td><h2 align="center">Color ID</h2></td>
<td><h2 align="center">Color Name</h2></td>
</tr>

<?php

$con = mysqli_connect("localhost","root","","website");

$sql = "select * from color";

$result = mysqli_query($con,$sql);

while($run = mysqli_fetch_assoc($result)){
    
   $col_id = $run['col_id'];
   $color_name = $run['col_name'];
echo "
<tr>
<td align='center'>$col_id</td>
<td align='center'>$color_name</td>
</tr>
";
}
?>
</table>
</div>
<?php
include("footer.php");
?>
</body>
</html>
<?php } ?>