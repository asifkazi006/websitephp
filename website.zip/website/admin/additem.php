<?php

session_start();

if(!isset($_SESSION['uname'])){
		
		header("location:index.php");
		
}
else{
	
?>
<?php
include("header.php");
include("nav-bar.php");
include("include/connection.php");
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>Add Item</title>
    <link rel="stylesheet" href="css/style.css"/>
    <style type="text/css">
    #add_item{
        margin-top: 20px;
    }
    </style>
</head>

<body>
<div id="add_item">
<form action="" method="post" enctype="multipart/form-data">
<table align="center" width="1200" border="2">
<tr>
<td colspan="2"><h1 align="center">Add New Product</h1></td>
</tr>
<tr>
<td align="center">Product Title</td>
<td><input type="text" name="pro_title" value="" required="required"/></td>
</tr>
<tr>
<td align="center">Product Category</td>
<td>
<select name="product_category">
<option>Select Product Category</option>
<?php
                
                
                $sql = "select * from product_cat";
                
                $result = mysqli_query($con,$sql);
                
                while($row = mysqli_fetch_array($result)){
                    
                    $product_id = $row[0];
                    $product_title = $row[1];
                  
                  
                  echo "<option value='$product_id'>$product_title</option>";   
            }
            ?>
</select>
</td>
</tr>
<tr>
<td align="center">Product Occasion</td>
<td>
<select name="product_occasion">
<option>Select Product Occasion</option>
<?php
                
                
                $sql = "select * from occasion_cat";
                
                $result = mysqli_query($con,$sql);
                
                while($row = mysqli_fetch_array($result)){
                    
                    $occasion_id = $row[0];
                    $occasion_title = $row[1];
                  
                  
                  echo "<option value='$occasion_id'>$occasion_title</option>";   
            }
            ?>
</select>
</td>
</tr>
<tr>
<td align="center">Product Varieties</td>
<td>
<select name="product_varieties">
<option>Select Product Varieties</option>
<?php
                
                
                $sql = "select * from varieties";
                
                $result = mysqli_query($con,$sql);
                
                while($row = mysqli_fetch_array($result)){
                    
                    $var_id = $row[0];
                    $var_title = $row[1];
                  
                  
                  echo "<option value='$var_id'>$var_title</option>";   
            }
            ?>
</select>
</td>
</tr>
<tr>
<td align="center">Product Color</td>
<td>

<select name="product_color">
<option>Select Product Color</option>
<?php
                
                
                $sql = "select * from color";
                
                $result = mysqli_query($con,$sql);
                
                while($row = mysqli_fetch_array($result)){
                    
                    $color_id = $row[0];
                    $color_title = $row[1];
                  
                  
                  echo "<option value='$color_id'>$color_title</option>";   
            }
            ?>
</select>
</td>
</tr>
<tr>
<td align="center">Product Image</td>
<td><input type="file" name="pro_image" value=""/></td>
</tr>
<td align="center">Product Price</td>
<td><input type="text" name="pro_price" value="" required="required"/></td>
</tr>
<td align="center">Product Old Price</td>
<td><input type="text" name="pro_old_price" value="" required="required"/></td>
</tr>
<td align="center">Product Description</td>
<td><textarea rows="5" cols="60" name="product_desc" required="required"></textarea></td>
</tr>
<tr>
<td align="center">Product Keyword</td>
<td><textarea rows="5" cols="60" name="product_keyword" required="required"></textarea></td>
</tr>
<tr>
<td align="center">Display At</td>
<td><input type="checkbox" name="homepage" required="required" value="1"/>Homepage</td>
</tr>
<tr>
<td align="center">Product Keyword</td>
<td><input type="checkbox" name="hot_offer" required="required" value="1"/>Hot Offer</td>
</tr>
<tr>
<td colspan="3" align="center"><input type="submit" name="submit" value="Insert Product" /></td>
</tr>
</table>
</form>
</div>
</body>
</html>

<?php

    if(isset($_POST['submit'])){
        
        //text variable
        
        
        $product_title = $_POST["pro_title"];
        $product_category = $_POST["product_category"];
        $product_occasion = $_POST["product_occasion"];
        $product_varieties = $_POST["product_varieties"];
        $product_color = $_POST["product_color"];
        $product_price = $_POST["pro_price"];
        $product_old_price = $_POST["pro_old_price"];
        $product_desc = $_POST["product_desc"];
        $product_keyword = $_POST["product_keyword"];
        $homepage = $_POST["homepage"];
        $hot_offer = $_POST["hot_offer"];
        
        // image variable
        
        $product_image = $_FILES["pro_image"]["name"];
        
        //tmp name of image
        
        $tmp_image = $_FILES["pro_image"]["tmp_name"];
        
        move_uploaded_file("$tmp_image","product_image/$product_image");
        
        $sql = "insert into product (product_title,pro_cat_id,pro_occ_id,pro_var_id,pro_col_id,product_image,pro_price,pro_old_price,pro_desc,pro_keyword,homepage,hot_offer) 
        
        values ('$product_title','$product_category','$product_occasion','$product_varieties','$product_color','$product_image','$product_price','$product_old_price','$product_desc','$product_keyword','$homepage','$hot_offer')";
        
        $result = mysqli_query($con,$sql);
        
        if($result)
        {
            echo "<script>alert('Product inserted successfully')</script>";
        }
    }

?>
<?php
include("footer.php");
?>
<?php } ?>