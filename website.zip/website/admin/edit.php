<?php

session_start();

if(!isset($_SESSION['uname'])){
		
		header("location:index.php");
		
}
else{
	
?>
<?php
include("header.php");
include("nav-bar.php");
include("include/connection.php");
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>Add Item</title>
    <link rel="stylesheet" href="css/style.css"/>
    <style type="text/css">
    #add_item{
        margin-top: 20px;
    }
    </style>
</head>
<body>
<div id="add_item">
<form action="" method="post" enctype="multipart/form-data">
<table align="center" width="1200" border="2">
<tr>
<td colspan="2"><h1 align="center">Add New Product</h1></td>
</tr>
<tr>
<td align="center">Product Title</td>
<td><input type="text" name="pro_title" value="" required="required"/></td>
</tr>
<tr>
<td align="center">Product Category</td>
<td>
<select name="product_category">
<option>Select Product Category</option>
<?php
                
                
                $sql = "select * from product_cat";
                
                $result = mysqli_query($con,$sql);
                
                while($row = mysqli_fetch_array($result)){
                    
                    $product_id = $row[0];
                    $product_title = $row[1];
                  
                  
                  echo "<option value='$product_id'>$product_title</option>";   
            }
            ?>
</select>
</td>
</tr>
<tr>
<td align="center">Product Occasion</td>
<td>
<?php
$sql = "select * from occasion_cat";
                
                $result = mysqli_query($con,$sql);
                
                while($row = mysqli_fetch_array($result)){
                    
                    $occasion_id = $row[0];
                    $occasion_title = $row[1];
                  
                  
                  echo "<input type='checkbox' name='product_occasion' value='$occasion_id'>$occasion_title";   
            }


?>
</td>
</tr>
<tr>
<td align="center">Product Varieties</td>
<td>
<?php
            
                $sql = "select * from varieties";
                
                $result = mysqli_query($con,$sql);
                
                while($row=mysqli_fetch_array($result)){
                    
                    $var_id = $row[0];
                    $var_title = $row[1];
                    
                  echo "<input type='checkbox' name='product_varieties' value='$var_id'>$var_title";   
            }
?>
</td>
</tr>
<tr>
<td align="center">Product Color</td>
<td>
<?php
            
                $sql = "select * from color";
                
                $result = mysqli_query($con,$sql);
                
                while($row=mysqli_fetch_array($result)){
                    
                    $color_id = $row[0];
                    $color_title = $row[1];
                    
                  echo "<input type='checkbox' name='product_color' value='$color_id'>$color_title";   
            }
?>
</td>
</tr>
<tr>
<td align="center">Product Image</td>
<td><input type="file" name="pro_image" value=""/></td>
</tr>
<td align="center">Product Price</td>
<td><input type="text" name="pro_price" value="" required="required"/></td>
</tr>
<td align="center">Product Old Price</td>
<td><input type="text" name="pro_old_price" value="" required="required"/></td>
</tr>
<td align="center">Product Description</td>
<td><textarea rows="5" cols="60" name="product_desc" required="required"></textarea></td>
</tr>
<tr>
<td align="center">Product Keyword</td>
<td><textarea rows="5" cols="60" name="product_keyword" required="required"></textarea></td>
</tr>
<!--<tr>
<td align="center">Display At</td>
<td><input type="checkbox" name="homepage" required="required"/>Homepage</td>
</tr>
<tr>
<td align="center">Product Keyword</td>
<td><input type="checkbox" name="hot_offer" required="required"/>Hot Offer</td>
</tr>-->
<tr>
<td colspan="3" align="center"><input type="submit" name="submit" value="Insert Product" /></td>
</tr>
</table>
</form>
</div>
</body>
</html>
<?php } ?>