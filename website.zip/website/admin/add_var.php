<?php

session_start();

if(!isset($_SESSION['uname'])){
		
		header("location:index.php");
		
}
else{
	
?>
<?php
include("header.php");
include("nav-bar.php");
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>Insert Varieties</title>
    <link rel="stylesheet" href="css/style.css"/>
    <style type="text/css">
    #var{
        float: left;
        margin-left: 100px;
        margin-top: 40px;
    }
    #var1{
        margin-top: 40px;
        margin-left: 100px;
    }
    </style>
</head>

<body>
<div id="var">
<form action="" method="post">
<h1 align="center" style="color: #FF8000;">Insert Varieties</h1>
<table width="300" height="150" border="2" align="center">
<tr>
<td align="center" style="color: #FF8000;">Varieties Name</td>
<td><input type="text" name="var_name" value=""/></td>
</tr>
<tr>
<td align="center" colspan="2"><input type="submit" name="submit" value="Insert" style="color: white; background: #FF8080;"/></td>
</tr>
</table>
</form>
</div>
<?php 

$con = mysqli_connect("localhost","root","","website");

if(isset($_POST['submit'])){

$var_name = $_POST["var_name"];

$sql = "insert into varieties (var_title) values ('$var_name')";

$result = mysqli_query($con,$sql);

if($result){
    
    echo "<script>alert('Varieties inserted successfully')</script>";
}

}
?>
<div id="var1">
<table width="500" border="2" align="center">
<tr>
<th colspan="3"><h2>Varieties Occasion</h2></th>
</tr>
<tr>
<td><h2 align="center">Varieties ID</h2></td>
<td><h2 align="center">Varieties Title</h2></td>
</tr>
<?php

$con = mysqli_connect("localhost","root","","website");

$sql = "select * from varieties";

$result = mysqli_query($con,$sql);

while($run = mysqli_fetch_assoc($result)){
    
    $var_id = $run['var_id'];
   $var_title = $run['var_title'];
echo "
<tr>
<td align='center'>$var_id</td>
<td align='center'>$var_title</td>
</tr>
";
}
?>
</table>
</div>
<?php
include("footer.php");
?>
</body>
</html>
<?php } ?>