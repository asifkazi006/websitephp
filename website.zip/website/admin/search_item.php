<?php

session_start();

if(!isset($_SESSION['uname'])){
		
		header("location:index.php");
		
}
else{
	
?>
<?php
include("header.php");
include("nav-bar.php");
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="gencyolcu" />

	<title>Search Product</title>
    <link rel="stylesheet" href="css/style.css"/>
    <style type="text/css">
    #search th{
        color: #c10000;
    }
    #search td{
        float: right;
        padding-right: 100px;
        color: #c10000;
    }
    .tab td{
        border:1px solid #f1f1f1;
        border-left: 0px;
        border-top: 0px;
        background-color: #f7f7f7;
        font-size: 14px;
        padding: 6px;
        color: #666666;
        font-weight: bold;
    }
    
    </style>
</head>

<body>
<div id="search">
<form action="" method="get" enctype="multipart/form-data">
<table width="1350">
<tr>
<th><h2>Search Item</h2></th>
<td><h3>Search (Product ID)</h3><input type="text" name="search" value="" placeholder="Product Id" required="required" size="10"/>
<input type="submit" name="submit" value="Search"/>
</td>
</tr>
</table>
</div>
<hr />
</form>
<table width="600" class="tab" align="center" border="1" style="margin-top: 60px;">
<tr>
<td>Pro ID</td>
<td>Image</td>
<td>Product Detail</td>
<td>Price</td>
<td>Edit</td>
</tr>
</table>
<?php
$con = mysqli_connect("localhost","root","","website");
if(isset($_GET['submit']))
{
    $search_id = $_GET['search'];
    
    $sql = "select * from product where product_id ='".$search_id."'";
    
    $result = mysqli_query($con,$sql);
    
    while($row=mysqli_fetch_array($result)){
        
        $pro_id = $row[0];
        $pro_image = $row[6];
        $pro_detail = $row[9];
        $pro_price = $row[7];
        
        echo "<table width='600' class='tab' align='center' border='1'>
<tr>
<td>$pro_id</td>
<td>$pro_image</td>
<td>$pro_detail</td>
<td>$pro_price</td>
<td><a href='edit.php'>Edit</a></td>
</tr>
</table>";
    }
}
?>
<?php
include("footer.php");
?>
</body>
</html>
<?php } ?>