 <?php
include("topbar.php");
include("navbar.php");
?>
<div id="florist_login">
<form action="florist-login-form.php" method="post">
<table width="300" align="center" style="background: #FEFDE9;">
<h1 style="color: orange;"align="center">Florist Login</h1>
<tr>
<td><label><b>Username</b></label></td>
<td><input type="text" name="uname" value="" required="required"/></td>
</tr>
<tr>
<td><label><b>Password</b></label></td>
<td><input type="password" name="pass" value="" required="required"/></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="sunmit" value="Login" style="margin-top: 9px;
    margin-left: 50px;
    background: #b20000;
    color: white;
    height: 28px;
    border: 0px solid #e1e1e1;
    cursor: pointer;
    margin-bottom: 5px;
    margin-right: 20px;"/></td>
</tr>
<tr>
<td><a href="forgot.php">Forgot Password</a></td>
<td><a href="florist-signup.php" style="padding-left: 50px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Register New</a></td>
</tr>
</table>
</form>
</div>
<?php
include("footer.php");
?>