<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>Page</title>
    <link rel="stylesheet" href="css/style.css"/>
    <style type="text/css">
    #main{
        width: 1100px;
        margin: auto;
        height: 360px;
        margin-top: 20px;
        margin-bottom: 20px;
        background:#f8f8ff;
        border: 2px solid #e5e5e5;
        
    }
    #head{
       width: 1100px;
       background: white; 
       height: 40px;
    }
    #left{
        width: 300px;
        background:	#f8f8ff;
        height: 320px;
        float: left;
        border: 1px solid #e5e5e5;
    }
    
    #img{
        margin-top: 15px;
        margin-left: 35px;
        border: 2px solid #e5e5e5;
    }
    #pro_id{
        
        font-weight: bold;
        margin-left: 20px;
    }
 
    #checkout{
        color: white;
        margin-top: 30px;
        margin-left: 960px;
        background: #b20000;
        display: block;
        padding: 4px 10px;
        border: 0px solid #e1e1e1;
        font-size: 17px;
        border-radius: 15px;
        box-shadow: 1px 1px 1px #a6a6a6;
        cursor: pointer;
        }
    #desc{
        width:1080px;
        background: white;
        height: 100px;
        border: 2px solid #e5e5e5;
    }
    #detail{
        width:1080px;
        background: white;
        height: 100px;
        margin-top: 10px;
        border: 2px solid #e5e5e5;
    }
    #head3{
        color:#b20000 ;
        font-size: 16pt;
        font-weight: bold;
        margin-left: 10px;
    }
    #para{
        color: #999999;
        font-size: 16px;
        margin-left: 10px;
    }
    #quan{
        margin-top: 20px;
        margin-left: 10px;
        border-radius: 2px;
        padding: 6px;
    }

    
    </style>
</head>

<body>
<?php
$con = mysqli_connect("localhost","root","","website");

    $pro_id = @$_GET["pro"];
    
    if(isset($_GET["pro"]))
    {
        $sql = "select * from product where product_id='".$pro_id."'";
        
        $result = mysqli_query($con,$sql);
        
        while($row=mysqli_fetch_array($result))
        {
            $product_id = $row[0];
            $product_title = $row[1];
            $product_price = $row[7];
            $product_desc = $row[9];
            $product_image = $row[6];

?>
<div id="main" >
<div id="head" style="background:#f8f8ff;">
<span style="color: #c10000; font-size: 19pt; margin-left: 20px;"><?php echo $product_title;?></span>
</div>
<div id="left">
<img src="admin/product_image/<?php echo $product_image;?>" width="220" height="220" alt="" id="img"/><hr />
<b id="pro_id">Product ID :<?php echo $product_id;?></b><hr />
</div>
<div id="right">
<div id="desc">
<b id="head3">Description : </b><br /><br />
<b id="para"><?php echo $product_desc;?></b>
</div>
<div id="detail">
<b id="head3">Add Quantity : </b><br />
<form action="" method="post">
<input type="text" name="quantity" value="" id="quan" required="required"/>
<input type="submit" name="quan" value="Add Quantity"/>
</form>
<?php 
$con = mysqli_connect("localhost","root","","website");

    if(isset($_POST['quan']))
    {
        $quantity = @$_POST["quantity"];
        
        $sql = "update product set quantity=".$quantity." where product_id=".$product_id."";
        
        $result = mysqli_query($con,$sql);
        
        if($result)
        {
            echo "<script>alert('Quantity added successfully');</script>";
        }
        
    }
?>
</div>
<form action="mycart.php?product=<?php echo $product_id;?>" method="post">
<input type="submit" name="submit" value="Add to Cart" id="checkout"/>
</form>
<?php } } ?>
</div>
</div>
</body>
</html>
<?php
include("footer.php");
?>