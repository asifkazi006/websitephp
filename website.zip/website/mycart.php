<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="gencyolcu" />

	<title>Cart</title>
    <style type="text/css">
    #cart{
        width: 1100px;
        height: 350px;
        margin: auto;
        margin-top: 20px;
    }
    table{
        margin-top: 20px;
        width:1000px;
        height:200px;
    }

    table th{
        color:#fff;
        text-align: center;
        width: 10%;
        background: #c10000;
    }
    table td{
        text-align: center;
        color:#000000;
        font-size: 18px;
        font-weight: Bold;
    }
    #checkout{
        float: right;
        color: white;
        margin-top: 30px;
        margin-right: 50px;
        background: #b20000;
        display: block;
        padding: 4px 10px;
        border: 0px solid #e1e1e1;
        font-size: 17px;
        border-radius: 15px;
        box-shadow: 1px 1px 1px #a6a6a6;

    }
    h2{
        padding-top: 15px;
        color:#c10000;
        font-size: 18pt;
        text-align: center;
    }
    </style>
</head>

<body>
<?php
include("topbar.php");
include("navbar.php");
?>
<?php
$con = mysqli_connect("localhost","root","","website");

    $pro_id = @$_GET["product"];
    
    if(isset($_GET["product"]))
    {
        $sql = "select * from product where product_id='".$pro_id."'";
        
        $result = mysqli_query($con,$sql);
        
        while($row=mysqli_fetch_array($result))
        {
            $product_id = $row[0];
            $product_price = $row[7];
            $product_image = $row[6];
            $product_quantity = $row[13];
        }
    }   
?>
 
<div id="cart">
<h2>My Shopping Cart Details</h2><hr />
<table align="center" border="1">
<tr>
<th>Items</th>
<th>Product ID</th>
<th>Price</th>
<th>Quantity</th>
<th>Edit</th>
</tr>
<tr>
<td><img src="admin/product_image/<?php echo $product_image;?>" width="82" height="82"/></td>
<td><?php echo $product_id;?></td>
<td><?php echo $product_price;?></td>
<td><?php echo $product_quantity;?></td>
<td><a href="" style="color:#c10000;">Remove</a></td>
</tr>
<tr style="background: #e5e5e5;">
<td></td>
<td></td>
<td></td>
<td>Total</td>
<td><?php echo $product_price*$product_quantity;?></td>
</tr>
<tr style="background: #e5e5e5;">
<td></td>
<td></td>
<td></td>
<td>Grand Total</td>
<td><?php echo $product_price*$product_quantity;?></td>
</tr>
</table>
<input type="submit" name="submit" value="Proceed To Checkout" id="checkout"/>
</div>
<?php
include("footer.php");
?>
</body>
</html>