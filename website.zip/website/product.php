<div id="product"> <!--product section start-->
<table>
<tr>
<td id="tabledata"><a href=""><img src="images/freshflowers.jpg" alt="" width="160" height="180" id="image"/></a></td>
<td id="tabledata"><a href=""><img src="images/stufftoys.jpg" alt="" width="160" height="180" id="image"/></a></td>
<td id="tabledata"><a href=""><img src="images/chocolates.jpg" alt="" width="160" height="180" id="image"/></a></td>
<td id="tabledata"><a href=""><img src="images/combo.jpg" alt="" width="160" height="180" id="image"/></a></td>
<td id="tabledata"><a href=""><img src="images/cakes.jpg" alt="" width="160" height="180" id="image"/></a></td>
<td id="tabledata"><a href=""><img src="images/fruits.jpg" alt="" width="160" height="180" id="image"/></a></td>
</tr>
<tr>
<td id="tabledata"><a href="">Fresh Flowers</td></a>
<td id="tabledata"><a href="">Stuff Toys</td></a>
<td id="tabledata"><a href="">Chocolates</td></a>
<td id="tabledata"><a href="">Combo</td></a>
<td id="tabledata"><a href="">Cakes</td></a>
<td id="tabledata"><a href="">Fruits<td></a>
</tr>
</div>
</table>
</div> <!--product section ends-->
