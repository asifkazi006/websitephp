<?php
include("topbar.php");
include("navbar.php");
?>
<div id="review">
<p><h3 style="color: orange;">Customer Review</h3></p>
<hr />
<div id="review_sec">
<table width="800">
<tr>
<td style="color: #ec9b4a; font-size: 16pt; font-family:Arial,Verdana;">Beautiful Arrangement</td>
<td></td>
</tr>
<tr>
<td><p style="font-family: Arial,Verdana; font-size: 11pt;"> U guyz made my day... She loved it so much... Specially the arrangements </p></td>
<td></td>
</tr>
<tr>
<td></td>
<td>By <strong style="color:#666666;font-size: 9pt;">Gautam Singh</strong></td>
</tr>
</table>
</div>
<div id="review_sec">
<table width="800">
<tr>
<td style="color: #ec9b4a; font-size: 16pt; font-family:Arial,Verdana;">Beautiful Arrangement</td>
<td></td>
</tr>
<tr>
<td><p style="font-family: Arial,Verdana; font-size: 11pt;"> U guyz made my day... She loved it so much... Specially the arrangements </p></td>
<td></td>
</tr>
<tr>
<td></td>
<td>By <strong style="color:#666666;font-size: 9pt;">Gautam Singh</strong></td>
</tr>
</table>
</div>
</div>
<?php
include("footer.php");
?>