<?php

$con = mysqli_connect("localhost","root","","website");

     $username = @$_POST["uname"];
     $password = @$_POST["pass"];

    
$sql = "select * from user_signup where user_email='".$username."' and user_pass='".$password."'";

    $result = mysqli_query($con,$sql);
    
    $res = @mysqli_num_rows($result);
    if($res>0)
    {
      echo "<script>window.open('user_dashboard.php','_self')</script>";
    }
    
    else
    {
        include("user-login.php");
        echo "<script>alert('Invalid Login Details')</script>";
    }
?>