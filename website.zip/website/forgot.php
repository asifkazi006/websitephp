<?php
include("topbar.php");
include("navbar.php");
?>
<div id="forgot_password">
<form action="" method="post">
<table align="center" width="300"  style="background: #FEFDE9" >
<tr>
<th colspan="2" align="left" style="font-family: arial;color: #b20000 ;padding:7px;background:#fff2cd;font-size: 18px;" >Forget Password</th>
</tr>
<tr>
<td align="center" style="padding: 2px 0px;font-weight: normal;color: #666666;font-size: 18px;">Username (Email)</td>
</tr>
<tr>
<td align="center"><input type="text" name="Email" value="" size="25" required="required" placeholder="Enter Email"/></td>
</tr>
<tr>
<td align="center"><input type="submit" name="submit" value="Send Password" style="background: #ec9b4a;display: block;border: 0px solid #e1e1e1;cursor: pointer;    border-radius: 3px;    padding: 4px 10px;font-size: 14px;"/></td>
</tr>
</form>
<tr>
<td><a href="user-login.php">User Login</a>
<a href="user-signup.php" style="float: right;">Register New</a></td>
</tr>
</table>
</div>
<?php
include("footer.php");
?>