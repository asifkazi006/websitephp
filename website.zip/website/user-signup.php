<?php
include("topbar.php");
include("navbar.php");
?>
<div id="user_signup">
<form action="user-register.php" method="post">
<table align="center" style="background: #FEFDE9;">
<tr>
<th colspan="2"><h3 style="color: #b20000;font-size: 20px;background:#fff2cd;">User Registration Form</h3><br /></th>
</tr>
<tr>
<td><label><b>UserName or (Email)</b></label></td>
<td><input type="text" name="uname" value="" required="required"/><span> * </span></td>
</tr>
<tr>
<td><label><b>Password</b></label></td>
<td><input type="password" name="pass" value="" required="required"/><span> * </span></td>
</tr>

<tr>
<td><label><b>Confirm Password</b></label></td>
<td><input type="password" name="con_pass" value="" required="required"/><span> * </span></td>
</tr>

<tr>
<td><label><b>FullName</b></label></td>
<td><input type="text" name="full_name" value="" required="required"/><span> * </span></td>
</tr>

<tr>
<td><label><b>Company Name</b></label></td>
<td><input type="text" name="com_name" value="" required="required"/><span> * </span></td>
</tr>

<tr>
<td><label><b>Address</b></label></td>
<td><textarea rows="4" cols="22" name="address" required="required"></textarea><span> * </span></td>
</tr>

<tr>
<td><label><b>City</b></label></td>
<td><input type="text" name="city" value="" required="required"/><span> * </span></td>
</tr>

<tr>
<td><label><b>State</b></label></td>
<td><input type="text" name="state" value="" required="required"/><span> * </span></td>
</tr>

<tr>
<td><label><b>Zip Code</b></label></td>
<td><input type="text" name="zipcode" value="" required="required"/><span> * </span></td>
</tr>

<tr>
<td><label><b>Country</b></label></td>
<td><input type="text" name="country" value="" required="required"/><span> * </span></td>
</tr>

<tr> 
<td><label><b>Mobile No</b></label></td>
<td><input type="text" name="mobile" value=""  required="required"/><span> * </span></td>
</tr>

<tr>
<td><label><b>Alternate Email</b></label></td>
<td><input type="text" name="alt_email" value="" required="required"/><span> * </span></td>
</tr>

<tr>
<td colspan="2" align="center"><input type="submit" name="submit" value="Register" style="margin-top: 9px;
    margin-left: 50px;
    background: #b20000;
    color: white;
    height: 28px;
    border: 0px solid #e1e1e1;
    cursor: pointer;
    margin-bottom: 5px;
    margin-right: 20px;"/></td>
</tr>
</table>
</form>

</div>
<?php
include("footer.php");
?>