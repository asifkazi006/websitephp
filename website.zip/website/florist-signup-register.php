<?php
$con = mysqli_connect("localhost","root","","website");
    
    if(isset($_POST[""]))
    {

    $email = $_POST["uname"];
    $pass = $_POST["pass"];
    $con_pass = $_POST["con_pass"];
    $fullname = $_POST["full_name"];
    $com_name = $_POST["com_name"];
    $address = $_POST["address"];
    $city = $_POST["city"];
    $state = $_POST["state"];
    $zipcode = $_POST["zipcode"];
    $country = $_POST["country"];
    $mobile = $_POST["mobile"];
    $alt_email = $_POST["alt_email"];
    
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
            
            include_once("florist-signup.php");
            echo "<script>alert('Invalid Email')</script>";
            die();
        }
        if($pass!=$con_pass){
            
            include_once("florist-signup.php");
            echo "<script>alert('Passowrd does not match')</script>";
            die();
        }
        if(!filter_var($alt_email,FILTER_VALIDATE_EMAIL)){
            include_once("florist-signup.php");
            echo "<script>alert('Invalid Alternate Email')</script>";
            die();
        }
    
    $sql = "insert into florist_signup(florist_email,florist_pass,florist_con_pass,florist_fullname,florist_comp,florist_add,florist_city,florist_state,florist_zip,florist_country,florist_mobile,florist_alt_email)values('$email','$pass','$con_pass','$fullname','$com_name','$address','$city','$state','$zipcode','$country','$mobile','$alt_email')";
    $result = mysqli_query($con,$sql);
    
    if($result){
        
        include("topbar.php");
        include("navbar.php");
        echo "<html>
        </head><title></title>
        </head>
        <style>
          #body-registration{
    
    margin-top: 20px;
    margin-bottom: 20px;
    width: 1100px;
    height: 200px;
    margin:auto;
    
}
#body-registration h2{
    
    color: #FF8000;
    padding-top: 60px;
}
#body-registration a{
    text-decoration: none;
    color: #FF8000;
} 
        </style>
        <body>
        ";
        echo "<div id='body-registration'>
        <h2 align='center'>Thank you for Registering with us</h2>
        <h3 align='center'><a href='florist-login.php'>Click here to login</a></h3>
        </div>";
        echo "</body>
        </html>";
        include("footer.php");
    }
    }   
?>