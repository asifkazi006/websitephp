<div id="footer"> <!--footer section start -->
<table style="width:1100px;padding:0px;border-spacing:0px;border:0px;margin: 0 auto;" >
<tr>
	<td colspan=3 style="border-top:2px solid #ec9b4a;text-align:center;" >&nbsp;</td>
</tr>
<td style="border-right:1px dotted #cccccc;text-align:left;padding-left:20px;vertical-align:top;" >
	<span style="color: orange;font-size: x-large;">Stay Connected</span><br><br>
     <a href="https://www.facebook.com/">
     <img src="images/facebook.png" alt=""/>
     </a>
     <a href="https://plus.google.com">
                <img src="images/google_plus.png" alt=""/>
      </a>
       <a href="https://twitter.com/">
                <img src="images/twitter.png" alt=""/>
       </a>
        <a href="https://in.pinterest.com/" >
                <img src="images/pinit.png" alt=""/>
        </a>
        <br />
        <img src="images/satisfaction.png" alt="" style="margin-top:15px; margin-left: 50px;"/>
</td>
	<td  style="text-align:left;padding-left:20px;border-right:1px dotted #cccccc;vertical-align:top;" >
	<span style="color: orange;font-size:x-large;">Reach us</span><br>
    <address style="font-size: 14pt; color: orange;">Wadala Mumbai 400031 <br />
    Mobile No : +918898669492</address>
</td>
<td style="text-align:left;padding-left:20px;vertical-align:top;" >
	<span style="color: orange;font-size:x-large;">Fast & Secure Ordering</span><br>
        <img alt="cc logos" src="images/cclogos.jpg" style="margin-top:5px;;" >
	</td>
</tr>
<tr>
	<td colspan=3 style="border-bottom:1px solid #ec9b4a;text-align:center;" >&nbsp;</td>
</tr>
</table>
<table style="width:1110px;border-spacing:0px;padding:0px;border:0px;margin: 0 auto;" >
<tr><td style="height:10px;text-align:center;" >
<table style="border:0px;width:1110px;border-spacing:0px;padding:0px;height:100%;" >
   <tr>
    <td style='padding:2px;color:#008000;font-size:14pt;background:#ffffff ;'>
        <table style="width:100%;border:0px;" class=foot_links>
       <tr style="vertical-align:top;">
        <td style="width:23%;" class=bord_right>
          <ul>
           <li>Pretty Petals</li>
           <li><a href="about.php">&raquo; About us</a></li>
           <li><a href="contact.php">&raquo; Contact us</a></li>
           <li><a href="review.php">&raquo; Customer Review</a></li>
          </ul>
        </td>
        <td style="width:23%;" class=bord_right>
          <ul>
           <li>Privacy & Legal</li>
           <li><a href="terms-condition.php">&raquo; Terms & Conditions</a></li>
           <li><a href="privacy-policy.php">&raquo; Privacy Policy</a></li>
           <li><a href="refund-policy.php">&raquo; Delivery & Refund Policy</a></li>
          </ul>
        </td>
        <td style="width:23%;" class=bord_right>
          <ul>
           <li>Ordering</li>
           <li><a href="user-login.php">&raquo; My Account</a></li>
           <li><a href="order-tracking.php">&raquo; Order Tracking</a></li>
          </ul>
        </td>
       
        <td style="width:15%;" class=bord_right>
          <ul>
           <li>Florist</li>
           <li><a href="florist-login.php">&raquo; Login</a></li>
           <li><a href="florist-signup.php">&raquo; Signup</a></li>
          </ul>
        </td>
        <td style="width:15%;" class=bord_right >
          <ul>
           <li>Customer</li>
           <li><a href="user-login.php">&raquo; Login</a></li>
           <li><a href="user-signup.php">&raquo; Signup</a></li>
          </ul>
        </td>
      </tr>
     </table>
    </td>
   </tr>
   <tr>
    <td>
        <table style="border:0px;width:100%;" >
        <tr style="text-align:center;">
         <td><!--<img src="<?php echo $backTo_TemplateRoot;?>images/footer_banner.jpg" width="515" height="86" border="0">--></td>
            <td><img alt="Mumbai" src="images/mumbai.jpg" style='border:0px;' ></td>
        </tr>
      </table>
    </td>
   </tr>
  </table>
  </td></tr>
  </table>
</div> <!--footer section ends-->
</div> <!--wrapper section ends-->
</body>
</html>
