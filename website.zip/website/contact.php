<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="gencyolcu" />

	<title>Contact</title>
    <style type="text/css">
    #contact_form{
        margin-top: 10px;
        margin-bottom: 20px;
    }
    
    #get_in_touch{
        margin-bottom: 20px;
    }
    p{
        font-size: 14px;
        font-family: Arial,Verdana;
        color:#666666;
    }
    
    </style>
</head>

<body>

<?php
include("topbar.php");
include("navbar.php");
?>
<div id="contact_us">
<div id="get_in_touch">
<h3 style="color: orange;">Get in Touch</h3>
<hr />
<table  width="500">
<tr>
<th>Mailing Address:</th>
<td style="color: orange;"><strong>PrettyPetals</strong></td>
</tr>
<tr>
<td></td>
<td><p>A superb collection of fresh flowers,cakes, <br />
chocolates, fruits and sweets delivered  to any <br/> 
location. Delivery on same day, midnight and Sunday</p></td>
</tr>
<tr>
<td></td>
<td><p>15 A, Union Park, Sherly Rajan Road,<br />
Pali Hill, Mumbai, Maharashtra, 400052, India</p></td>
</tr>
<tr>
<td></td>
<td>
<p><strong>Phone</strong>: +912226044913<br />
<strong>Mobile</strong>: +919833100194<br />
support@prettypetals.com<br />
orders@prettypetals.co.in<br />
Monday through Sunday, 8-8pm</p></td>
</tr>
<tr>
<th>Contact Us:</th>

<td>
<p><strong>Email</strong> : support@prettypetals.com<br />
<strong>Phone</strong> : +91 9833100194 
</p></td></tr>
</table>
</div>
<div id="send_message">
<h3 style="color: orange;">Send Message</h3>
<hr />
<div id="contact_form">
<form action="" method="">
<input type="text" name="" value="" size="40" placeholder="Your Name" required="required"/><br /><br />
<input type="text" name="" value="" size="40" placeholder="Your Contact No" required="required"/><br /><br />
<input type="text" name="" value="" size="40" placeholder="Your Email ID" required="required"/><br /><br />
<textarea name="" rows="8" cols="42" placeholder="Write Your Message/Enquiry/Query Here" required="required"></textarea></textarea><br />
<input type="submit" name="submit" value="Send Message"/>
</form>
</div>
</div>
</div>
<?php
include("footer.php");
?>
</body>
</html>