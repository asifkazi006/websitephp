<?php

$con = mysqli_connect("localhost","root","","website");

    if(isset($_POST["submit"]))
    {

    $del_date = $_POST["date"];
    $del_time = @$_POST["del_time"];
    $msg = $_POST["msg"];
    $send_name_card = $_POST["sender_name"];
    $rec_name = $_POST["rec_name"];
    $rec_zip = $_POST["rec_zip"];
    $rec_add = $_POST["rec_add"];
    $rec_city = $_POST["rec_city"];
    $rec_mobile = $_POST["rec_mobile"];
    $rec_state = $_POST["rec_state"];
    $rec_country = $_POST["rec_country"];
    $rec_email = $_POST["rec_email"];
    $send_name = $_POST["send_name"];
    $send_zip = $_POST["send_zip"];
    $send_add = $_POST["send_add"];
    $send_city = $_POST["send_city"];
    $send_mobile = $_POST["send_mobile"];
    $send_state = $_POST["send_state"];
    $send_country = $_POST["send_country"];
    $send_email = $_POST["send_email"];
    $modes_of_payment = @$_POST["mode_of_payment"];
    $terms = @$_POST["agree"];
    
   if(empty($del_date))
   {
        echo "<script>alert('Select the date')</script>";
        include_once("order-detail.php");
   }
   
   if(empty($del_time))
   {
        echo "<script>alert('Select the Delivery time')</script>";
        include_once("order-detail.php");
   }
    if(!filter_var($rec_email,FILTER_VALIDATE_EMAIL))
    {
        echo "<script>alert('Invalid Receiver Email')</script>";
        include_once("order-detail.php");
    }
    
    if(!filter_var($send_email,FILTER_VALIDATE_EMAIL))
    {
        echo "<script>alert('Invalid Sender Email')</script>";
        include_once("order-detail.php");
    }
    if(empty($modes_of_payment))
   {
        echo "<script>alert('Select Mode of Payment')</script>";
        include_once("order-detail.php");
   }

    if(!isset($terms))
    {
    echo "<script>alert('Accept Terms and Condition')</script>";
    include_once("order-detail.php");
   }
   else{
    echo "success";
   }
    
   
    
/*$sql = "insert into order_detail (del_date,del_time,msg_card,sender_name_card,receiver_name,receiver_zip,receiver_add,receiver_city,receiver_mob,receiver_state,receiver_country,receiver_email,sender_name,sender_zip,sender_add,sender_city,sender_mob,sender_state,sender_country,sender_email,modes_of_payment) 

values ('$del_date','$del_time','$msg','$send_name_card','$rec_name','$rec_zip','$rec_add','$rec_city','$rec_mobile','$rec_state','$rec_country','$rec_email','$send_name','$send_zip','$send_add','$send_city','$send_mobile','$send_state','$send_country','$send_email','$modes_of_payment')" ;


$result = mysqli_query($con,$sql);

if($result)
{
    echo "<script>alert('Inserted successfully')</script>";
}*/
}
?>

<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>Order-Detail</title>
    <style type="text/css">
    #order_detail{
        
        width: 1000px;
        margin: auto;
        background: #F9FDD9;
        height: auto;
        margin-top: 20px;
        margin-bottom: 20px;
    }
    #checkout{
        color: white;
        margin-top: 30px;
        margin-left: 400px;
        background: #b20000;
        display: block;
        padding: 4px 10px;
        border: 0px solid #e1e1e1;
        font-size: 17px;
        border-radius: 15px;
        box-shadow: 1px 1px 1px #a6a6a6;

    }
    #checkbox{
        margin-top: 20px;
        margin-left: 300px;
    }
    table th{
        font-family: arial;
            color: #b20000;
            text-align: center;
            font-size: 18px;
            background: #fff2cd;
            margin: 0px;
            padding: 7px;
            
    }
    table label{
        font-weight: normal;
        color: #666666;
        font-size: 16px;
        
    }
    table td{
        height:40px;
    }
    table span{
        color: red;
    }
    </style>
    
</head>

<body>
<?php
include("topbar.php");
include("navbar.php");
?>
<div id="order_detail">
<form action="order-detail.php" method="post">
<table  width="600" align="center">
<tr><th colspan="2">Delivery Details</th></tr>
<tr>
<td align="center"><label>Delivery Date</label></td>
<td><input type="date" name="date" value=""/><span> * </span></td>
</tr>
<tr>
<td align="center"><label>Delivery Time</label></td>
<td><input type="radio" name="del_time" value="before 2pm"/>Before 2pm
<input type="radio" name="del_time" value="after 2pm"/>After 2pm</td>
</tr>
<tr>
<td align="center"><label>Message on the Card</label></td>
<td><textarea rows="5" cols="40" name="msg" placeholder="Write Message here" required="required"></textarea><span> * </span></td>
</tr>
<tr>
<td align="center"><label>Sender Name on card</label></td>
<td><input type="text" name="sender_name" value="" required="required"/><span> * </span></td>
</tr>
<tr>
<th colspan="2">Receiver Details</th>
</tr>
<tr>
<td align="center"><label>Receiver Name</label> <br />
<input type="text" name="rec_name" value="" align="center" required="required"/><span> * </span></td>
<td align="center"><label>Zip Code</label><br />
<input type="text" name="rec_zip" value=""/><span> * </span>  
</td>
</tr>
<tr>
<td align="center"><label>Receiver Address</label> <br />
<textarea rows="3" cols="25" align="center" required="required" name="rec_add"></textarea><span> * </span></td>
<td align="center"><label>City</label><br />
<input type="text" name="rec_city" value="" align="center"/> <span> * </span>  
</td>
</tr>
<tr>
<td align="center"><label>Mobile No</label> <br />
<input type="text" name="rec_mobile" value="" required="required"/><span> * </span></td>
<td align="center"><label>State</label><br />
<input type="text" name="rec_state" value="" required="required"/><span> * </span>   
</td>
</tr>
<tr>
<td align="center"><label>Country</label> <br />
<input type="text" name="rec_country" value="" required="required"/><span> * </span></td>
<td align="center"><label>Email ID</label><br />
<input type="text" name="rec_email" value="" required="required"/><span> * </span>  
</td>
</tr>
<tr>
<th colspan="2">Sender Details</th>
</tr>
<tr>
<td align="center"><label>Sender Name</label> <br />
<input type="text" name="send_name" value="" required="required"/><span> * </span></td>
<td align="center"><label>Zip Code</label><br />
<input type="text" name="send_zip" value="" required="required"/><span> * </span>   
</td>
</tr>
<tr>
<td align="center"><label>Sender Address</label> <br />
<textarea rows="3" cols="25" required="required" name="send_add"></textarea><span> * </span></td>
<td align="center"><label>City</label><br />
<input type="text" name="send_city" value="" required="required"/> <span> * </span>  
</td>
</tr>
<tr>
<td align="center"><label>Mobile No</label> <br />
<input type="text" name="send_mobile" value="" required="required"/><span> * </span></td>
<td align="center"><label>State</label><br />
<input type="text" name="send_state" value="" required="required"/><span> * </span>   
</td>
</tr>
<tr>
<td align="center"><label>Country</label> <br />
<input type="text" name="send_country" value="" required="required"/><span> * </span></td>
<td align="center"><label>Email ID</label><br />
<input type="text" name="send_email" value="" required="required"/> <span> * </span>  
</td>
</tr>
<tr>
<th colspan="2">Modes of Payment</th>
</tr>
<tr>
<td colspan="2" align="center" height="80"><input type="radio" name="mode_of_payment" value="Cash on delivery"/>Cash on Delivery</td>
</tr>
</table>
<input type="checkbox" name="agree" value="" id="checkbox" /> I have read and agree to the Terms & Conditions of<br />
<input type="submit" name="submit" value="Proceed To Checkout" id="checkout"/>
</form>
</div>
</body>
</html>
<?php
include("footer.php");
?>
