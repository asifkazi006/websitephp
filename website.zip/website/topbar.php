<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="content-type" content="text/html" />
<meta name="author" content="gencyolcu" />

<title>Homepage</title>
<link rel="stylesheet" href="css/style.css" type="text/css"/>
<link href="css/js-image-slider.css" rel="stylesheet" type="text/css" />
<script src="js/js-image-slider.js" type="text/javascript"></script>
<style type="text/css">
#img{
	width:550px;
	height:80px;
	background:white;
	float:left;
}
#search_bar{
    width:550px;
	height:80px;
	background:white;
	float:right;
}
#search{
    margin-top: 7px;
    outline: 0px;
    padding: 5px;
    border-radius: 2px;
}
#button{
    margin-top: 9px;
    margin-left: 50px;
    background: #b20000;
    color: white;
    height: 28px;
    border: 0px solid #e1e1e1;
    cursor: pointer;
}
span{
	margin-left:10px;
	color:#ec9b4a;
	font-size: 13pt;
}

</style>
</head>
<body>
<div id="wrapper"> <!--wrapper section start -->
<div id="topbar"> <!-- topbar section start -->
<div id="img">
<a href="index.php"><img src="images/logo.jpg" alt="logo" style="margin-top:8px;"/></a>
<img src="images/sdelivery.jpg" alt="logo" style="margin-left: 14px;"/>
</div>
<div id="search_bar">
<form action="" method="">
<input type="text" name="search" id="search" required="required"/>
<a href="order-tracking.php" style="color:#FF8000; text-decoration:none;">Track Order</a>
<span>Order online or call</span>
<span>+918898669492</span>
<br />
<input type="submit" name="submit" value="Search" id="button"/>
<a href="" style="text-decoration: none;"><img src="images/cart.jpg" alt="cart" style="margin-left:180px;"/>
<span>Item</span></a>
<span style="margin-left: 75px;">022 24122412</span>
</form>
</div>
</div>  <!-- topbar section ends -->