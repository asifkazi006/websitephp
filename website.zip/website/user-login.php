<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="content-type" content="text/html" />
<meta name="author" content="gencyolcu" />

<title>User Login</title>
<link rel="stylesheet" href="css/style.css" type="text/css"/>
<link href="css/js-image-slider.css" rel="stylesheet" type="text/css" />
<script src="js/js-image-slider.js" type="text/javascript"></script>

<style type="text/css">
#button{
    margin-top: 9px;
    margin-left: 50px;
    background: #b20000;
    color: white;
    height: 28px;
    border: 0px solid #e1e1e1;
    cursor: pointer;
    margin-bottom: 5px;
    margin-right: 20px;
}
</style>
</head>
<body>
<?php
include("topbar.php");
include("navbar.php");
?>

<div id="user_login">
<form action="user-login-form.php" method="post">
<table width="300" align="center" style="background: #FEFDE9;">
<h1 style="color: orange;"align="center">User Login</h1>
<tr>
<td><label><b>Username</b></label></td>
<td><input type="text" name="uname" value="" required="required"/></td>
</tr>
<tr>
<td><label><b>Password</b></label></td>
<td><input type="password" name="pass" value="" required="required"/></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="sunmit" value="Login" id="button"/></td>
</tr>
<tr>
<td width="150"><a href="forgot.php">Forgot Password</a></td>
<td><a href="user-signup.php" style="padding-left: 30px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Register New</a></td>
</tr>
</table>
</form>
</div>
<?php
include("footer.php");
?>
</body>
</html>
