<?php
include("topbar.php");
include("navbar.php");
?>
<div id="terms_condition" style="background: url('images/page_back.jpg')repeat-x;" >
<h1 style="color: #c10000;">Terms & Condition</h1>
<p>Pretty Petals has blossomed over the years into the worlds's finest floral kiosk. Pollinating their passion for flowers with their spirit of entrepreneurship, the promoters gave seed to Pretty Petals, sprinkling the venture with dedication and enterprise.</p>
<p>Determined to offer the very best in variety and service, the promoters diligently developed an extensive global network for sourcing and delivery of flowers, thus equipping Pretty Petals with the capability to service any order for flowers 24x7, at virtually any location in the World </p>
<p>Ever since inception, professional service was the overriding priority , as Pretty Petals went about delivering not just flowers but smiles too. Every order, be it a bunch of flowers or a floral assignment was promptly executed, and from a trickle initially, orders began to pour in. Today, more than orders from new customers who have heard about Pretty Petals exceptional service, repeat orders from delighted customers drive our growing popularity and sales.</p>
<p>Pretty Petals is worlds premier florist and floral designer reputed for its warm, dependable and personalized service. With years of rich and eventful floristry experience, we offer an ever blooming range of floral services for every conceivable need from private events to corporate events, festival decor, corporate decor and home decor. Pretty Petals specialises is its Express daily bouquet delivery service. On request, we also delivers cakes, chocolates, balloons and soft toys along with your flowers to enhance the presentation. And whether you order at our friendly shop or online, you can be assured of professional and value-for-money service.</p>
<p>Home, or rather garden to the most exotic flowers, Pretty Petals offers a breathtaking variety, unavailable elsewhere in the world . This ardent focus on variety is what makes us , a flower kiosk that distinctly, a cut above the rest. With fresh cut flowers for every reason and occasion arranged in stunning combinations and wrapped to perfection in a choice of styles, you wll find that gifting flowers to your near & dear is best, when its done with a Pretty Petals Bouquet.</p>
<p>Pretty Petals is a one-stop shop for a range of floral gifting and allied services. What special about us is the extraordinary lengths it goes to, in order to delight its customers. To enable customers make truly special gifts to their loved ones, - Chocolates and more</p>
</div>
<?php
include("footer.php");
?>