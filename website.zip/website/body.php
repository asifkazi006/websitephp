<?php

$con = mysqli_connect("localhost","root","","website");

if(!$con){
    die("Error in Connection");
}

$sql = "select * from product where homepage =1";

$result = mysqli_query($con,$sql);
                
                while($row = mysqli_fetch_array($result)){
                    
              $product_image = $row[6];  
              $product_title = $row[1];
?>
<div id="body"> <!-- body section start-->
<table id="tableid">
<tr>
<td id="bodydata"><a href=""><img src="admin/product_image/<?php echo $product_image;?>" alt="" width="200" height="200" id="bodyimage"/></a></td>
</tr>
<tr>
<td id="bodydata"><a href=""><?php echo $product_title;?></td></a>
</tr>
</table>
</div> <!-- body section ends-->
<?php } ?>